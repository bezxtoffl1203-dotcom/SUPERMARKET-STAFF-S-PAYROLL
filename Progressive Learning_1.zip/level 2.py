#overtime pay
hours_worked = int(input("Hours worked : "))
hourly_rate = int(input("Hourly rate : "))
basic_wage= hours_worked*hourly_rate
print("Basic wages :",basic_wage)


#overtime pay
if hours_worked >= 8:
    basic_wage=8*hourly_rate
    extra_hours=hours_worked-8
    overtime_pay=extra_hours * hourly_rate * 1.5
else:
    basic_wage=hours_worked*hourly_rate
    overtime_pay=0
total_wages=basic_wage+overtime_pay
print("Basic wage:",int(basic_wage))
print("Overtime pay:",int(overtime_pay))
print("total wages:",int(total_wages))
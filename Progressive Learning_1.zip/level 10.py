#Multiple employees
n = int(input("Number of employees : "))
total_wage_bill=0
names=[]
wages=[]
grocessary_total=0
diary_total=0
bakery_total=0

for i in range(1, n + 1):
    print("employee",i)
    name=input("Enter the employee name :")
    hours_worked=int(input("Hours worked : "))
    hourly_rate = int(input("Hourly rate : "))
    department=int(input("Enter the no of Department :"))
    basic_wage= hours_worked*hourly_rate
    print("Basic wages :",basic_wage)


#overtime pay
    if hours_worked >= 8:
        basic_wage=8*hourly_rate
        extra_hours=hours_worked-8
        overtime_pay=extra_hours * hourly_rate * 1.5
    else:
        basic_wage=hours_worked*hourly_rate#
        overtime_pay=0
    total_wages=basic_wage+overtime_pay
    print("Basic wage:",int(basic_wage))
    print("Overtime pay:",int(overtime_pay))
    print("total wages:",int(total_wages))

#bonus
    rating=int(input("Enter the rating:"))
    if rating==3:
        bonus=500
    elif rating==2:
        bonus=200
    else:
        bonus=0
    total_wages=basic_wage+overtime_pay
    gross_wages=total_wages+bonus
    print("Basic wage:",int(basic_wage))
    print("Overtime pay:",int(overtime_pay))
    print("Bonus:",bonus)
    print("gross wages:",int(gross_wages))


#tax deduction
    if gross_wages>2000:
        tax=gross_wages*0.20
    elif gross_wages>=1000:
        tax=gross_wages*0.10
    else:
        tax=0
    net_wages=gross_wages-tax
    total_wage_bill+=net_wages
    wages.append(total_wages)
    names.append(name)
    lowest_wages=min(wages)


    
    employee_number_highest=1
    employee_number_lowest=1
    print("Employee ",i,"Net wage",net_wages)
    if department==1:
      grocessary_total+=net_wages
    elif department==2:
        diary_total+=net_wages
    else:
        bakery_total+=net_wages

print("Wages :",wages)
print("Total Wage Bill :",total_wage_bill)


average_wage=total_wage_bill/len(wages)
highest_wage=max(wages)
highest_index=wages.index(highest_wage)
highest_paid_name=names[highest_index]
lowest_index=wages.index(lowest_wages)
lowest_paid_name=names[lowest_index]


print("Average wage:",average_wage)
print("Highest Paid :",highest_paid_name,"-",highest_wage)
print("Lowest paid :",lowest_paid_name,"-",lowest_wages)
above_count=0
below_count=0

for wage in wages:
    if wage>average_wage:
        above_count+=1
    elif wage<average_wage:
        below_count+=1
print("Above Average :",above_count,"employee")
print("Below Average :",below_count,"employee")



print("Grocessary_total :",grocessary_total)
print("Diary_total :",diary_total)
print("Bakery_total :",bakery_total)

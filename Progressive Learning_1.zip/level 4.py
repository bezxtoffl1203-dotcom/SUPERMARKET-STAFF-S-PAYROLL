#basic wages
hours_worked=int(input("Hours worked : "))
hourly_rate = int(input("Hourly rate : "))
basic_wage= hours_worked*hourly_rate
print("Basic wages :",basic_wage)


#overtime pay
if hours_worked >= 8:
    basic_wage=8*hourly_rate
    extra_hours=hours_worked-8
    overtime_pay=extra_hours * hourly_rate * 1.5
else:
    basic_wage=hours_worked*hourly_rate#
    overtime_pay=0
total_wages=basic_wage+overtime_pay
print("Basic wage:",int(basic_wage))
print("Overtime pay:",int(overtime_pay))
print("total wages:",int(total_wages))

#bonus
rating=int(input("Enter the rating:"))
if rating==3:
    bonus=500
elif rating==2:
    bonus=200
else:
    bonus=0
total_wages=basic_wage+overtime_pay
gross_wages=total_wages+bonus
print("Basic wage:",int(basic_wage))
print("Overtime pay:",int(overtime_pay))
print("Bonus:",bonus)
print("gross wages:",int(gross_wages))


#tax deduction
if gross_wages>2000:
    tax=gross_wages*0.20
elif gross_wages>=1000:
    tax=gross_wages*0.10
else:
    tax=0
net_wages=gross_wages-tax
print("Gross wages",int(gross_wages))
print("Tax",int(tax))
print("Net wages",int(net_wages))
# Read input from the user and calculate basic wages
hours_worked = int(input("Hours worked : "))
hourly_rate = int(input("Hourly rate : "))
basic_wage= hours_worked*hourly_rate
print("Basic wages :",basic_wage)
